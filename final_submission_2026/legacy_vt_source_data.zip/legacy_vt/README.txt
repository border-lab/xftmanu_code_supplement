Scope: Original 5-trait VT=0.05, mate correlation=0.1, GxE variance=0/0.05 at residual correlations 0/0.1/0.2. Covers ED1 and these ED10 conditions only; not all older VT campaigns.

Recovery: 4608 original per-individual CSVs, read without changes. Recomputed direct h2 and direct-score correlation matched original summary tables within 1e-10 for every row.

Matrices: original_covariance_blocks.npz stores covariance and weights in the exact row order of recovered_direct_score_projections.csv; row_index is zero-based. Covariance order: y0–y4 addGen, then y0–y4 phenotype.

Weights: W=G^-1 C in original units, full 5x5 matrix without symmetry imposed. Mean own weight averages 5 diagonal entries; mean other weight averages 20 off-diagonal entries.

Ratios: Ratio of those within-replicate mean weights, then summarized across replicates; not a ratio of the across-replicate means.

Interpretation: These are direct-genetic-component projections. For GxE conditions, do not identify them with the unrestricted best linear prediction from all genotypes. Existing HE estimates are retained separately.

Native data: Individual-level simulation files need not be distributed: the original full covariance blocks suffice to reproduce all exported weights/projections.

Verification: Run python reproduce_weights.py. Source table checksums, matching errors and provenance are in verification.json and the recovered row metadata.
