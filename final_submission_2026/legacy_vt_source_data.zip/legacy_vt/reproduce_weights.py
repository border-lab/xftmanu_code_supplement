#!/usr/bin/env python3
"""Check all recovered full fitted matrices from saved original covariance blocks."""
from pathlib import Path
import numpy as np
import pandas as pd
from general_vt_weights import fit_from_covariance

ROOT=Path(__file__).resolve().parent
def main():
    data=np.load(ROOT/'original_covariance_blocks.npz')
    table=pd.read_csv(ROOT/'full_fitted_weights.csv')
    expected=table.weight.to_numpy().reshape(-1,5,5)
    errors=[]
    for cov,w,exported in zip(data['covariance'],data['weights'],expected,strict=True):
        fitted=fit_from_covariance(cov[:5,:5],cov[:5,5:],cov[5:,5:])['weights']
        errors.extend([np.max(abs(fitted-w)),np.max(abs(fitted-exported))])
    assert len(expected)==4608 and max(errors)<1e-12
    print(f'Verified {len(expected)} full 5x5 weight matrices; maximum error {max(errors):.3g}.')

if __name__=='__main__':main()
