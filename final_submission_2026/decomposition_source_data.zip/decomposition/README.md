# Source data: apparent-component weights and genetic decomposition

This package collects the existing round-five simulation results underlying current
Figure 4 (formerly Figure 3), Extended Data Figures 4 and 5, Supplementary Figure S17,
and Supplementary Tables S7 and S8. Data cover generations 0–5. It also includes
the population-GWAS false-positive inflation results used in Figure 4d.

The October 2 update adds fitted apparent-component weights, their explicitly
defined ratio, and numeric summaries from the same preserved simulation inputs.

These are simulation outputs. Empirical CCA and UK Biobank/Taiwan correlation
summaries are supplied separately in Supplementary Tables S2–S4.

## Figure and table mapping

| Current display | Round-five display | Data file | Selection |
|---|---|---|---|
| Figure 4b | Figure 3b | `data/main_scenarios_replicates.csv` | `starting_h2=0.5`, `metric=h2` |
| Figure 4c | Figure 3c | Same | `starting_h2=0.5`, `metric=rg` |
| Figure 4d | Figure 3d | `data/figure4d_replicates.csv` | All rows; population GWAS only |
| ED5a–b | ED4a–b | `data/main_scenarios_replicates.csv` | `starting_h2=0.25`; `h2` for a, `rg` for b |
| ED4a–b | ED5a–b | `data/vt_structure_replicates.csv` | `starting_h2=0.5`; `h2` for a, `rg` for b |
| S17a–b | S17a–b | Same | `starting_h2=0.25`; `h2` for a, `rg` for b |
| Table S7 | Table S7 | `summaries/table_S7_generation5_means.csv` | All rows; generation-five means |
| Table S8 | Table S8 | `summaries/table_S8_generation5_means.csv` | All rows; generation-five means |

Figure 4a consists of model diagrams and has no plotted numeric observations.

## Replicates and statistics

Each row in `data/` is one simulation replicate for one generation, metric, and
component (or one power setting for Figure 4d). Seed numbers identify replicates
within a simulation configuration. Repeated generations and different metrics
from the same seed are not additional independent replicates.

- Main scenarios: 200 replicates per scenario at starting h²=0.5; 50 at h²=0.25.
- VT structures at starting h²=0.5: 200 replicates per structure and mating regime.
- VT structures at starting h²=0.25: 50 replicates for `no VT` and
  `strong (constant)`; 200 for the other three structures, in each mating regime.
- Figure 4d: 250 replicates per scenario and nominal-power setting.

The decomposition plots display medians with 10th–90th percentile intervals.
Figure 4d displays medians without error bars. The `summaries/` files include
`n`, `median`, `p10`, and `p90`, plus the arithmetic mean and sample standard
deviation (`sd`, denominator n−1). Quantiles use linear interpolation, matching
R's default type-7 quantiles. Tables S7/S8 use generation-five means, not medians.
The new mean-table exports retain full precision and include `n_replicates`.

The continuum endpoints reuse the same simulation results as the main scenarios.
They must not be pooled as independent additional runs. The source files also
contain 2xAM runs and within-sibship GWAS results not used in these displays;
those remain in `inputs/round5/` for provenance, but are excluded from `data/`.

## Data dictionary

| Field | Meaning |
|---|---|
| `starting_h2` | Generation-zero heritability parameter (0.25 or 0.5) |
| `scenario` | RM, RM + VT, 5xAM, or 5xAM + VT |
| `mating` | Random mating (`RM`) or five-variate assortative mating (`5xAM`) |
| `structure` | Original round-five VT-structure label |
| `generation` | Generation, from 0 through 5 |
| `metric` | Heritability (`h2`) or genetic correlation (`rg`) |
| `component` | `direct`, `apparent` (exact best linear predictor), or `estimated` |
| `seed` | Original simulation seed within its configuration |
| `value` | Corresponding metric; in Figure 4d, empirical/theoretical type-I error ratio |
| `nominal_power` | Original nominal power label: 39%, 50%, or 66% |
| `GWAS` | `Population` in Figure 4d source data |

`estimated` corresponds to the original `LDSC` plot label. The source estimator
columns are Haseman–Elston estimates (`he_h2`, `he_rg`), as explained in Methods.
The labels and values have not been changed to imply a different estimator.

`inputs/decomposition_inputs.csv.gz` contains the numeric inputs necessary to
recompute the decomposition for every original replicate. It combines 3,500
per-seed source files, preserving their 21,000 generation rows. It includes:
`seed`, `gen`; original model arguments `args_kphen`, `args_rmate`, `args_theta`,
`args_h2`, `args_m`, `args_m_causal`; `h2_true`, `rg_true`; the genotype–phenotype
covariances `cov_g_y` and `cov_g_y_cross`; and estimates `he_h2`, `he_rg`.
`xvt` is parsed from the original filename for the three continuum campaigns
(0, 0.125, 0.5) and is blank for the main-scenario inputs. `source_group` and
`source_file` identify the original file; its checksum is recorded in
`provenance/raw_input_files.csv`. Parameters are retained as recorded in each
campaign, including the number of causal variants.

## Apparent-component weights

The following numerical exports use the original round-five calculation and the
same saved moments as the decomposition figures; no simulations were rerun.

| File | Contents |
|---|---|
| `data/apparent_weights_replicates.csv` | 21,000 replicate-generation rows from all 3,500 preserved input files, including unused two-trait inputs for provenance |
| `summaries/main_scenarios_apparent_weights.csv` | 48 condition-generation summaries for Figure 4b–c and ED5; generation-five means also support S8 |
| `summaries/vt_structure_apparent_weights.csv` | 120 condition-generation summaries for ED4 and S17; generation-five means also support S7 |

Let `g` be the vector of direct genetic components and `Y` the phenotype vector.
The existing calculation reconstructs compound-symmetric matrices
`G = Cov(g) / Var(Y)` and `C = Cov(g, Y) / Var(Y)` from the pooled saved moments,
using the common phenotype-variance normalization of these symmetric examples.
Their diagonal/off-diagonal entries are respectively
`(h2_true, h2_true * rg_true)` and `(cov_g_y, cov_g_y_cross)`.
The fitted weight matrix is `W = solve(G, C)`; column k predicts phenotype k.
Thus the apparent component for trait k is
`own_trait_weight * g_k + other_trait_weight * sum(g_j for j != k)`.
These are the fitted apparent-component weights, not the parental-transmission
coefficients used to specify the model. The reconstruction pools traits under
the same symmetry assumption as the original figures; it does not recover a
separate unrestricted matrix of finite-sample coefficients for each replicate.

| New field | Meaning |
|---|---|
| `own_trait_weight` | Common diagonal entry of W |
| `other_trait_weight` | Common off-diagonal entry: weight on each other trait, not their combined weight |
| `other_to_own_ratio` | `other_trait_weight / own_trait_weight`, computed within each replicate |
| `apparent_h2` | Common diagonal of `C.T @ W`, using the original normalization |
| `apparent_rg` | Mean off-diagonal of the correlation matrix obtained from `C.T @ W` |
| `used_in_main_decomposition` | Selects the Figure 4b–c / ED5 input rows |
| `used_in_vt_structure_decomposition` | Selects the ED4 / S17 input rows |
| `n_traits` | Number of traits in the preserved simulation |
| `cross_mate_correlation` | Original `args_rmate` input parameter |
| `vt_variance_parameter` | Original `args_theta` input parameter |
| `vt_structure_parameter` | Original `xvt` parameter when supplied; blank for main-campaign inputs |

The summary files include `n_replicates` and the mean, sample SD, median, and
10th/90th percentiles of each of the five numeric quantities. Ratio summaries
summarize replicate-level ratios; they are not ratios of summarized weights.
Small signed weights arising from simulation variability are retained without
rounding or clipping. The same input row can have both selection flags true:
continuum endpoints reuse the main scenarios and are not independent replicates.

**Coverage:** this archive provides Figure 4b–d plotting data and fitted weights
for the Figure 4b–c, ED4/5, S17, and Tables S7/S8 decomposition examples. It does
not by itself cover every VT example in the paper and supplement. The separate
`figure5_source_data.zip` now contains the recovered original Figure 5 inputs and
full identified 2-by-3 weight matrices for 200 replicates over generations 0–5.
The separate `legacy_vt_source_data.zip` contains the retained VT conditions in
ED1 and the residual-correlation 0/0.1/0.2 conditions in ED10; its coverage is
explicitly limited to those conditions. No substitute simulation campaign was
used, and no new simulations were run for these exports.

## Reproduce and verify

With Python, numpy, and pandas installed, run:

```sh
python scripts/aggregate.py
python scripts/export_apparent_weights.py
```

The script writes only inside this package. It reconstructs G and C for each
replicate, computes `M = C.T @ solve(G, C)`, and checks all direct, apparent,
and estimated results against the canonical round-five exports within 1e−12.
It then creates the combined replicate files and summaries from those original
exports. It does not rerun the simulations or alter their outputs.

Optionally run `Rscript --vanilla scripts/verify_statistics.R` to check all
summary statistics independently against base R, including the plot quantiles.

The six CSVs in `inputs/round5/` are byte-for-byte copies of the original exports.
`provenance/original_scripts/` preserves the processing and plotting scripts used
to establish the source selections and statistics. Those historical scripts have
original local paths and numbering; use `scripts/aggregate.py` to rebuild this
portable package. The archived plotting scripts document numerical treatment;
final artwork layout and colour changes are maintained in the figure workspace.

`export_apparent_weights.py` checks the matrix solution against an independent
closed-form solution, verifies `G @ W = C` and `W.T @ G @ W = C.T @ W`, and
matches every relevant replicate-generation h²/rg value to the existing figure
data within 1e−12. Its report is `provenance/apparent_weights_verification.json`.

Verification reports in `provenance/` record recomputation checks, agreement with
the current Figure 4 panel exports, and agreement with the displayed values in
Tables S7/S8. `SHA256SUMS` lists all packaged files for integrity checks.

This is a locally prepared source-data package. Repository deposition and the
final availability statement are tracked separately in the submission checklist.

## General linear VT example

`general_vt_example.md` explains how to specify general parental coefficients and
extract a full fitted matrix from each generation of xftsim covariance output.
The numerical helper is `scripts/general_vt_weights.py`; its independent OLS and
label-order checks are recorded in `provenance/general_vt_helper_verification.json`.
The primary decomposition exports retain their original symmetric calculation.
