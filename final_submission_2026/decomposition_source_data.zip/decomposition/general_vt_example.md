# General linear VT: model specification and fitted weights

The parental transmission coefficients define the simulation model. The fitted
weights discussed in the review are a different matrix: they predict offspring
phenotypes from offspring direct genetic components. These fitted weights can
change across generations even when the parental coefficients stay fixed.

## Specify the transmission model

The existing xftsim user guide shows a nonconstant matrix of maternal and paternal
phenotype effects using `LinearVerticalComponent`, explicit input/output component
indices, founder initialization, and a choice of input normalization:

https://xftsim.readthedocs.io/en/latest/userguide/arch.html#multivariate-vertical-transimission

Rows of `coefficient_matrix` index offspring output components; columns index the
parental inputs in `input_cindex`. Consult those index labels before assigning
coefficients. Maternal and paternal coefficients can differ. This matrix is not
restricted to the equal diagonal/off-diagonal structure used in the symmetric
examples in the manuscript. Founder initialization, noise variance, normalization,
and the mating regime must also be specified; a coefficient matrix alone does not
fully define a simulation.

## Extract the fitted matrix in every generation

Include `xftsim.stats.SampleStatistics` in the simulation's statistics, with its
covariance output enabled and the required direct genetic and phenotype components
selected. Covariances are stored as documented here:

https://xftsim.readthedocs.io/en/latest/userguide/stats.html

For the manuscript simulations, direct genetic components are named `addGen`;
the documentation's demo uses `additiveGenetic`. Specify the actual labels, rather
than relying on their incidental order in a covariance table.

```python
from pathlib import Path
import pandas as pd
from general_vt_weights import from_sample_statistics

# Example labels: replace with those in YOUR simulation.
traits = ['y0', 'y1', 'y2', 'y3', 'y4']
genetic_keys = [(t, 'addGen', 'proband') for t in traits]
phenotype_keys = [(t, 'phenotype', 'proband') for t in traits]
output = Path('weights')
output.mkdir(exist_ok=True)
for generation, stored in sorted(sim.results_store.items()):
    vcov = stored['sample_statistics']['vcov']
    fitted = from_sample_statistics(vcov, genetic_keys, phenotype_keys)
    fitted['weights'].to_csv(output / f'weights_generation_{generation}.csv')
    pd.DataFrame(fitted['projected_correlation'], index=traits, columns=traits).to_csv(
        output / f'correlations_generation_{generation}.csv')
    pd.Series(fitted['projected_variance_fraction'], index=traits, name='variance_fraction').to_csv(
        output / f'variance_fractions_generation_{generation}.csv')
```

Here `G = Cov(g)`, `C = Cov(g,Y)` and `V = Cov(Y)` retain their original units.
The code solves `G W = C`. Rows of `W` index the direct genetic components and
columns index predicted traits; the predicted centered phenotype matrix is `g @ W`.
Its covariance is `W.T @ G @ W`. Dividing each diagonal by the corresponding
diagonal of `V` gives the projected variance fraction, and standardizing this
projected covariance gives its correlation matrix. No trait symmetry is imposed.

The code returns the best linear projection onto the supplied direct-score basis.
This is the apparent-component construction used for the manuscript's additive,
linear-VT decomposition. For other architectures, especially arbitrary nonlinear
or interaction models, this restricted projection must not automatically be
identified with the best linear predictor from all genotypes. The primary
decomposition CSVs retain their original pooled symmetry calculation; this helper
does not silently replace them with a different finite-sample fit.

Zero-variance direct components or linear dependencies make individual weights
unidentified. The helper raises an error instead of silently selecting a
pseudo-inverse. Choose an independent genetic basis explicitly; a phenotype with
no direct genetic component can still be an outcome. Correlations of zero-variance
projections are undefined and returned as missing, not forced to zero.

Run `python scripts/general_vt_weights.py` to check the numerical helper against
independent least-squares fitting, known unequal coefficients, reordered xftsim-style
labels, and singular/zero-variance cases. These are numerical/API-shape checks;
they do not rerun xftsim simulations.
