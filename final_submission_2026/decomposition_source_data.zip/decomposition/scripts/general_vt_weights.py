#!/usr/bin/env python3
"""Fit a full, unrestricted direct-score projection from covariance blocks.

Rows of W index direct genetic components; columns index outcome phenotypes.
This does not require exchangeability or equal own/cross-trait coefficients.
See general_vt_example.md for interpretation and xftsim integration.
"""
import numpy as np
import pandas as pd


def fit_from_covariance(G, C, Y):
    """Return W, projected covariance, variance fractions, and correlations.

    G = Cov(g), C = Cov(g,Y), Y = Cov(Y), all in the SAME original units.
    Genetic components must be linearly independent. No pseudo-inverse,
    regularization, clipping, or replacement of unidentified weights is used.
    """
    G, C, Y = (np.asarray(a, dtype=float) for a in (G, C, Y))
    if G.ndim != 2 or G.shape[0] != G.shape[1] or C.ndim != 2:
        raise ValueError('G must be square and C must be a matrix.')
    if C.shape[0] != len(G) or Y.shape != (C.shape[1], C.shape[1]):
        raise ValueError('Incompatible covariance block dimensions.')
    if not all(np.isfinite(a).all() for a in (G, C, Y)):
        raise ValueError('Covariances must be finite.')
    joint = np.block([[G, C], [C.T, Y]])
    if not np.allclose(joint, joint.T, rtol=1e-10, atol=1e-12):
        raise ValueError('Covariance matrix must be symmetric.')
    eig = np.linalg.eigvalsh(joint)
    if eig.min() < -1e-10 * max(1., np.linalg.norm(joint, 2)):
        raise ValueError('The joint covariance matrix is not positive semidefinite.')
    if np.linalg.matrix_rank(G) < len(G):
        raise ValueError('Direct components are linearly dependent: individual weights are not identified. Select an independent basis explicitly.')
    if (np.diag(Y) <= 0).any():
        raise ValueError('Outcome variances must be positive.')
    W = np.linalg.solve(G, C)
    projected = W.T @ G @ W
    sd = np.sqrt(np.maximum(projected.diagonal(), 0))
    denom = np.outer(sd, sd)
    corr = np.full(projected.shape, np.nan)
    np.divide(projected, denom, out=corr, where=denom > 0)
    return {'weights': W, 'projected_covariance': projected,
            'projected_variance_fraction': projected.diagonal() / Y.diagonal(),
            'projected_correlation': corr, 'condition_number': float(np.linalg.cond(G))}


def from_sample_statistics(vcov, genetic_keys, phenotype_keys):
    """Use explicit xftsim SampleStatistics MultiIndex labels in desired order.

    Keys are tuples, e.g. ('y0', 'addGen', 'proband'). Inspect your own vcov
    labels: components are named 'additiveGenetic' in the documentation demo.
    """
    if not vcov.index.is_unique or not vcov.columns.is_unique:
        raise ValueError('Covariance labels must be unique.')
    if not vcov.index.equals(vcov.columns):
        raise ValueError('Rows and columns must use the same ordered labels.')
    if len(set(genetic_keys)) != len(genetic_keys) or len(set(phenotype_keys)) != len(phenotype_keys):
        raise ValueError('Selection keys must be unique within each set.')
    result = fit_from_covariance(vcov.loc[genetic_keys, genetic_keys],
                                 vcov.loc[genetic_keys, phenotype_keys],
                                 vcov.loc[phenotype_keys, phenotype_keys])
    result['weights'] = pd.DataFrame(result['weights'],
                                     index=pd.MultiIndex.from_tuples(genetic_keys),
                                     columns=pd.MultiIndex.from_tuples(phenotype_keys))
    return result


def verify():
    """Check against independent OLS, known asymmetric weights and singularity."""
    rng = np.random.default_rng(8264)
    g = rng.normal(size=(4000, 3)) @ np.array([[1., .2, 0], [0, .8, .3], [.1, 0, 1.2]])
    g -= g.mean(0)
    truth = np.array([[1.1, .25], [-.3, .9], [.4, -.1]])
    e = rng.normal(size=(len(g), 2))
    e -= e.mean(0)
    e -= g @ np.linalg.lstsq(g, e, rcond=None)[0]
    y = g @ truth + e
    cov = np.cov(np.column_stack([g, y]), rowvar=False)
    result = fit_from_covariance(cov[:3,:3], cov[:3,3:], cov[3:,3:])
    np.testing.assert_allclose(result['weights'], truth, atol=1e-12)
    np.testing.assert_allclose(result['weights'], np.linalg.lstsq(g, y, rcond=None)[0], atol=1e-12)
    np.testing.assert_allclose(result['projected_covariance'], np.cov(g @ truth, rowvar=False), atol=1e-12)
    keys = [('a','addGen','proband'), ('b','addGen','proband'), ('c','addGen','proband'), ('a','phenotype','proband'), ('b','phenotype','proband')]
    index = pd.MultiIndex.from_tuples(keys, names=['phenotype_name','component_name','vorigin_relative'])
    frame = pd.DataFrame(cov, index=index, columns=index)
    reordered = from_sample_statistics(frame, [keys[2],keys[0],keys[1]], [keys[4],keys[3]])
    np.testing.assert_allclose(reordered['weights'], truth[[2,0,1]][:,[1,0]], atol=1e-12)
    try: fit_from_covariance(np.ones((2,2)), np.ones((2,1)), np.ones((1,1))*2)
    except ValueError as exc: assert 'not identified' in str(exc)
    else: raise AssertionError('A singular basis must be rejected.')
    zero = fit_from_covariance(np.eye(2), np.zeros((2,1)), np.eye(1))
    assert np.isnan(zero['projected_correlation']).all()
    return {'independent_OLS': True, 'asymmetric_known_weights': True,
            'reordered_multiindex_keys': True, 'singular_basis_rejected': True,
            'zero_variance_correlation_undefined': True,
            'numpy': np.__version__, 'pandas': pd.__version__}


if __name__ == '__main__':
    import json
    print(json.dumps(verify(), indent=2))
