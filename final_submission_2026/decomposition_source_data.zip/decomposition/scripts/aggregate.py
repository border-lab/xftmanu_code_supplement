#!/usr/bin/env python3
"""Rebuild figure-ready source data and validate the round-five decomposition.

Run from any directory: python /path/to/decomposition/scripts/aggregate.py
Requires numpy and pandas. All outputs stay inside this source-data package.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'inputs'
SCENARIOS = ['RM', 'RM + VT', '5xAM', '5xAM + VT']
STRUCTURES = ['no VT', 'uVT (same-trait)', 'weak (½ total)',
              'weak (½ per-trait)', 'strong (constant)']
QUANTITIES = {'Direct h²': 'direct', 'Apparent h²': 'apparent',
              'LDSC h²': 'estimated', 'Direct r_g': 'direct',
              'Apparent r_g': 'apparent', 'LDSC r_g': 'estimated'}


def read_csv(path):
    return pd.read_csv(path, float_precision='round_trip')


def save(frame, path):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(target, index=False, float_format='%.17g', lineterminator='\n')


def summary(frame, keys):
    assert not frame.duplicated(keys + ['seed']).any()
    assert np.isfinite(frame['value']).all()
    out = frame.groupby(keys, sort=True, dropna=False)['value'].agg(
        n='size', mean='mean', sd='std', median='median',
        p10=lambda x: x.quantile(0.1, interpolation='linear'),
        p90=lambda x: x.quantile(0.9, interpolation='linear')).reset_index()
    return out


def validate_apparent():
    raw = read_csv(INPUT / 'decomposition_inputs.csv.gz')
    assert not raw.duplicated(['source_group', 'source_file', 'gen']).any()
    assert len(raw) == 21000
    # The original R scripts form M = C.T @ solve(G, C), with compound-
    # symmetric G and C. Perform that same calculation on every replicate.
    raw['apparent_h2'] = np.nan
    raw['apparent_rg'] = np.nan
    for k, sub in raw.groupby('args_kphen'):
        k = int(k)
        a = sub.h2_true.to_numpy()
        b = (sub.h2_true * sub.rg_true).to_numpy()
        c = sub.cov_g_y.to_numpy()
        d = sub.cov_g_y_cross.to_numpy()
        eye = np.eye(k)
        G = b[:, None, None] + (a - b)[:, None, None] * eye
        C = d[:, None, None] + (c - d)[:, None, None] * eye
        M = np.swapaxes(C, 1, 2) @ np.linalg.solve(G, C)
        diag = np.diagonal(M, axis1=1, axis2=2)
        R = M / np.sqrt(diag[:, :, None] * diag[:, None, :])
        raw.loc[sub.index, 'apparent_h2'] = diag.mean(axis=1)
        raw.loc[sub.index, 'apparent_rg'] = R[:, np.triu_indices(k, 1)[0],
                                             np.triu_indices(k, 1)[1]].mean(axis=1)
    raw['scenario'] = np.where(raw.args_rmate == 0, 'RM',
                               raw.args_kphen.astype(str) + 'xAM')
    raw.loc[raw.args_theta > 0, 'scenario'] += ' + VT'
    raw['mating'] = np.where(raw.args_rmate == 0, 'RM', '5xAM')
    raw['structure'] = raw['xvt'].map({0: 'uVT (same-trait)',
                                     0.125: 'weak (½ total)',
                                     0.5: 'weak (½ per-trait)'})
    raw.loc[raw.args_theta == 0, 'structure'] = 'no VT'
    raw.loc[raw.xvt.isna() & (raw.args_theta == 0.05), 'structure'] = 'strong (constant)'
    results = {}
    for campaign, prefix in [('main', 'fig3_vdecomp_r5'),
                             ('continuum', 'fig_continuum_r5')]:
        selected = raw[raw.source_group != 'vdecomp_xvt'].copy() if campaign == 'main' else raw[raw.args_kphen == 5].copy()
        keys = ['gen', 'seed', 'scenario', 'args_h2'] if campaign == 'main' else ['gen', 'seed', 'structure', 'mating', 'args_h2']
        assert not selected.duplicated(keys).any()
        for metric, original_value in [('h2', 'h2'), ('rg', 'rg')]:
            ref = read_csv(INPUT / 'round5' / f'{prefix}_{metric}_long.csv')
            if campaign == 'main':
                ref = ref.rename(columns={'h2_param': 'args_h2'})
            ref['component'] = ref.quantity.map(QUANTITIES)
            components = {'direct': f'{metric}_true',
                          'apparent': f'apparent_{metric}',
                          'estimated': f'he_{metric}'}
            merged = ref.merge(selected[keys + list(components.values())],
                               on=keys, validate='many_to_one')
            assert len(merged) == len(ref)
            predicted = np.array([merged.loc[i, components[merged.loc[i, 'component']]]
                                  for i in merged.index])
            error = float(np.max(np.abs(predicted - merged[original_value].to_numpy())))
            np.testing.assert_allclose(predicted, merged[original_value], rtol=1e-12, atol=1e-12)
            results[f'{campaign}_{metric}'] = {'rows': len(ref), 'max_absolute_error': error}
    return results


def combine(prefix, campaign):
    parts = []
    for metric in ['h2', 'rg']:
        d = read_csv(INPUT / 'round5' / f'{prefix}_{metric}_long.csv')
        d = d.rename(columns={'gen': 'generation', 'h2_param': 'starting_h2',
                              'args_h2': 'starting_h2', metric: 'value'})
        d['component'] = d.quantity.map(QUANTITIES)
        assert d.component.notna().all()
        d['metric'] = metric
        if campaign == 'main':
            d = d[d.scenario.isin(SCENARIOS)]
            keys = ['starting_h2', 'scenario', 'generation', 'metric', 'component']
        else:
            keys = ['starting_h2', 'mating', 'structure', 'generation', 'metric', 'component']
        parts.append(d[keys + ['seed', 'value']])
    result = pd.concat(parts, ignore_index=True).sort_values(keys + ['seed']).reset_index(drop=True)
    assert not result.duplicated(keys + ['seed']).any()
    assert set(result.generation) == set(range(6))
    return result, keys


def table_summary(summaries, index):
    d = summaries[summaries.generation == 5].copy()
    d['column'] = d.metric + '_' + d.component
    wide = d.pivot(index=index, columns='column', values='mean').reset_index()
    counts = d.groupby(index)['n'].agg(['min', 'max']).reset_index()
    assert (counts['min'] == counts['max']).all()
    wide = wide.merge(counts[index + ['min']].rename(columns={'min': 'n_replicates'}), on=index)
    return wide[index + ['n_replicates', 'h2_direct', 'h2_apparent', 'h2_estimated',
                         'rg_direct', 'rg_apparent', 'rg_estimated']]


def main():
    comparison = validate_apparent()
    main_data, main_keys = combine('fig3_vdecomp_r5', 'main')
    continuum, continuum_keys = combine('fig_continuum_r5', 'continuum')
    fp = read_csv(INPUT / 'round5' / 'fig3_vdecomp_r5_fp.csv')
    fp = fp[(fp.GWAS == 'Population') & fp.scenario.isin(SCENARIOS)].copy()
    fp = fp.rename(columns={'gen': 'generation', 'relative_T1R': 'value', 'power': 'nominal_power'})
    fp_keys = ['scenario', 'nominal_power', 'GWAS', 'generation']
    fp = fp[fp_keys + ['seed', 'value']].sort_values(fp_keys + ['seed']).reset_index(drop=True)
    main_s = summary(main_data, main_keys)
    continuum_s = summary(continuum, continuum_keys)
    fp_s = summary(fp, fp_keys)
    save(main_data, 'data/main_scenarios_replicates.csv')
    save(continuum, 'data/vt_structure_replicates.csv')
    save(fp, 'data/figure4d_replicates.csv')
    save(main_s, 'summaries/main_scenarios_summary.csv')
    save(continuum_s, 'summaries/vt_structure_summary.csv')
    save(fp_s, 'summaries/figure4d_summary.csv')
    save(table_summary(continuum_s, ['starting_h2', 'mating', 'structure']),
         'summaries/table_S7_generation5_means.csv')
    save(table_summary(main_s, ['starting_h2', 'scenario']),
         'summaries/table_S8_generation5_means.csv')
    report = {'raw_decomposition_matches_round5': comparison,
              'replicate_rows': {'main_scenarios': len(main_data), 'vt_structure': len(continuum), 'figure4d': len(fp)},
              'summary_rows': {'main_scenarios': len(main_s), 'vt_structure': len(continuum_s), 'figure4d': len(fp_s)},
              'statistics': 'Median and type-7 (linear) 10th/90th quantiles reproduce plotted decomposition centres and intervals. Means and sample SD are additional summaries; S7/S8 use means.',
              'checks': ['unique replicate keys', 'finite values', 'generations 0–5', 'exact source-row coverage',
                         'matrix-recomputed decomposition agrees with original round-5 CSVs within 1e-12']}
    target = ROOT / 'provenance/aggregation_verification.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
