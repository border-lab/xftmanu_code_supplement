#!/usr/bin/env Rscript
# Independent verification against the statistics used by the original R plots.
arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- gsub("~+~", " ", sub("^--file=", "", arg), fixed = TRUE)
root <- normalizePath(file.path(dirname(script_path), ".."), mustWork = TRUE)
cases <- c("main_scenarios", "vt_structure", "figure4d")
result <- list()
for (name in cases) {
  d <- read.csv(file.path(root, "data", paste0(name, "_replicates.csv")),
                stringsAsFactors = FALSE, check.names = FALSE)
  reference <- read.csv(file.path(root, "summaries", paste0(name, "_summary.csv")),
                        stringsAsFactors = FALSE, check.names = FALSE)
  keys <- setdiff(names(d), c("seed", "value"))
  calc <- aggregate(d$value, d[keys], function(x) {
    c(n = length(x), mean = mean(x), sd = sd(x), median = median(x),
      p10 = unname(quantile(x, 0.1, type = 7)),
      p90 = unname(quantile(x, 0.9, type = 7)))
  })
  calc <- cbind(calc[keys], as.data.frame(calc$x))
  merged <- merge(calc, reference, by = keys, suffixes = c("_R", "_Python"))
  stopifnot(nrow(merged) == nrow(reference), nrow(calc) == nrow(reference))
  for (statistic in c("n", "mean", "sd", "median", "p10", "p90")) {
    delta <- max(abs(merged[[paste0(statistic, "_R")]] -
                     merged[[paste0(statistic, "_Python")]]))
    stopifnot(is.finite(delta), delta < 1e-10)
    result[[length(result) + 1L]] <- data.frame(dataset = name,
      statistic = statistic, groups = nrow(merged), max_absolute_error = delta)
  }
}
out <- do.call(rbind, result)
write.csv(out, file.path(root, "provenance/R_statistics_verification.csv"), row.names = FALSE)
print(out)
