#!/usr/bin/env python3
"""Export fitted apparent-component weights from preserved round-five moments.

Run after aggregate.py. No simulation is rerun. Writes only within this package.
Uses the original compound-symmetric reconstruction from pooled moments, not
an unrestricted weight matrix estimated separately for each finite sample.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
VALUES = ['own_trait_weight', 'other_trait_weight', 'other_to_own_ratio',
          'apparent_h2', 'apparent_rg']


def read(path):
    return pd.read_csv(ROOT / path, float_precision='round_trip')


def save(frame, path):
    frame.to_csv(ROOT / path, index=False, float_format='%.17g', lineterminator='\n')


def summarize(frame, keys):
    assert not frame.duplicated(keys + ['seed']).any()
    grouped = frame.groupby(keys, sort=True, dropna=False)
    result = grouped.size().rename('n_replicates').to_frame()
    for value in VALUES:
        stats = grouped[value].agg(mean='mean', sd='std', median='median',
                                  p10=lambda x: x.quantile(.1, interpolation='linear'),
                                  p90=lambda x: x.quantile(.9, interpolation='linear'))
        result = result.join(stats.add_prefix(value + '_'))
    return result.reset_index()


def verify_figure_quantities(weights, campaign, keys):
    original = read('data/' + campaign + '_replicates.csv')
    expected_keys = original[keys + ['seed']].drop_duplicates()
    assert len(weights) == len(expected_keys)
    assert not weights.duplicated(keys + ['seed']).any()
    coverage = weights[keys + ['seed']].merge(expected_keys, on=keys + ['seed'],
                                             how='outer', indicator=True,
                                             validate='one_to_one')
    assert (coverage['_merge'] == 'both').all()
    errors = {}
    for metric in ['h2', 'rg']:
        ref = original[(original.component == 'apparent') & (original.metric == metric)]
        matched = weights.merge(ref[keys + ['seed', 'value']], on=keys + ['seed'],
                                validate='one_to_one')
        assert len(matched) == len(weights) == len(ref)
        predicted = matched['apparent_' + metric]
        np.testing.assert_allclose(predicted, matched.value, rtol=1e-12, atol=1e-12)
        errors[metric] = float(abs(predicted - matched.value).max())
    return {'replicate_generation_rows': len(weights),
            'exact_figure_key_coverage': True, 'max_absolute_errors': errors}


def main():
    d = read('inputs/decomposition_inputs.csv.gz')
    assert len(d) == 21000
    assert not d.duplicated(['source_group', 'source_file', 'gen']).any()
    assert d[['source_group', 'source_file']].drop_duplicates().shape[0] == 3500
    assert set(d.gen) == set(range(6))
    errors = {'normal_equation': 0., 'closed_form_weights': 0., 'covariance_identity': 0.}
    minimum_eigenvalue = float('inf')
    for k, sub in d.groupby('args_kphen'):
        assert k == int(k) and k >= 2
        k = int(k)
        a = sub.h2_true.to_numpy()
        b = (sub.h2_true * sub.rg_true).to_numpy()
        c = sub.cov_g_y.to_numpy()
        cross = sub.cov_g_y_cross.to_numpy()
        G = b[:, None, None] + (a - b)[:, None, None] * np.eye(k)
        C = cross[:, None, None] + (c - cross)[:, None, None] * np.eye(k)
        mineig = float(np.linalg.eigvalsh(G).min())
        assert mineig > 0
        minimum_eigenvalue = min(minimum_eigenvalue, mineig)
        weights = np.linalg.solve(G, C)
        own = np.diagonal(weights, axis1=1, axis2=2).mean(axis=1)
        other = weights[:, ~np.eye(k, dtype=bool)].mean(axis=1)
        assert np.all(own != 0)
        # Independent scalar solution in the common and contrast eigenspaces.
        common = (c + (k - 1) * cross) / (a + (k - 1) * b)
        contrast = (c - cross) / (a - b)
        own_closed = (common + (k - 1) * contrast) / k
        other_closed = (common - contrast) / k
        np.testing.assert_allclose(own, own_closed, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(other, other_closed, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(G @ weights, C, rtol=1e-12, atol=1e-12)
        M = np.swapaxes(C, 1, 2) @ weights
        reconstructed = np.swapaxes(weights, 1, 2) @ G @ weights
        np.testing.assert_allclose(M, reconstructed, rtol=1e-12, atol=1e-12)
        diagonal = np.diagonal(M, axis1=1, axis2=2)
        correlation = M / np.sqrt(diagonal[:, :, None] * diagonal[:, None, :])
        d.loc[sub.index, 'own_trait_weight'] = own
        d.loc[sub.index, 'other_trait_weight'] = other
        d.loc[sub.index, 'other_to_own_ratio'] = other / own
        d.loc[sub.index, 'apparent_h2'] = diagonal.mean(axis=1)
        d.loc[sub.index, 'apparent_rg'] = correlation[:, np.triu_indices(k, 1)[0],
                                                       np.triu_indices(k, 1)[1]].mean(axis=1)
        errors['normal_equation'] = max(errors['normal_equation'], float(abs(G @ weights - C).max()))
        errors['closed_form_weights'] = max(errors['closed_form_weights'],
                                           float(abs(own - own_closed).max()),
                                           float(abs(other - other_closed).max()))
        errors['covariance_identity'] = max(errors['covariance_identity'],
                                           float(abs(M - reconstructed).max()))
    assert np.isfinite(d[VALUES]).all().all()
    d['mating'] = np.where(d.args_rmate == 0, 'RM', d.args_kphen.astype(int).astype(str) + 'xAM')
    d['scenario'] = d['mating'] + np.where(d.args_theta > 0, ' + VT', '')
    d['structure'] = d.xvt.map({0: 'uVT (same-trait)', .125: 'weak (½ total)',
                              .5: 'weak (½ per-trait)'})
    d.loc[d.args_theta == 0, 'structure'] = 'no VT'
    d.loc[d.xvt.isna() & (d.args_theta == .05), 'structure'] = 'strong (constant)'
    assert d.structure.notna().all()
    d['used_in_main_decomposition'] = ((d.source_group != 'vdecomp_xvt') &
                                       d.scenario.isin(['RM', 'RM + VT', '5xAM', '5xAM + VT']))
    d['used_in_vt_structure_decomposition'] = d.args_kphen == 5
    d = d.rename(columns={'args_h2': 'starting_h2', 'gen': 'generation',
                          'args_kphen': 'n_traits', 'args_rmate': 'cross_mate_correlation',
                          'args_theta': 'vt_variance_parameter', 'xvt': 'vt_structure_parameter'})
    main_data = d[d.used_in_main_decomposition]
    continuum = d[d.used_in_vt_structure_decomposition]
    main_keys = ['starting_h2', 'scenario', 'generation']
    continuum_keys = ['starting_h2', 'mating', 'structure', 'generation']
    figure_checks = {
        'main_scenarios': verify_figure_quantities(main_data, 'main_scenarios', main_keys),
        'vt_structure': verify_figure_quantities(continuum, 'vt_structure', continuum_keys),
    }
    columns = ['source_group', 'source_file', 'seed', 'generation', 'starting_h2',
               'n_traits', 'cross_mate_correlation', 'vt_variance_parameter',
               'vt_structure_parameter', 'scenario', 'mating', 'structure',
               'used_in_main_decomposition', 'used_in_vt_structure_decomposition'] + VALUES
    exported = d[columns].sort_values(['source_group', 'source_file', 'generation'])
    main_summary = summarize(main_data, main_keys)
    vt_summary = summarize(continuum, continuum_keys)
    save(exported, 'data/apparent_weights_replicates.csv')
    save(main_summary, 'summaries/main_scenarios_apparent_weights.csv')
    save(vt_summary, 'summaries/vt_structure_apparent_weights.csv')
    report = {
        'source_replicates': 3500, 'replicate_generation_rows': len(exported),
        'vt_replicate_generation_rows': int((d.vt_variance_parameter > 0).sum()),
        'generation_range': [0, 5], 'summary_rows': {'main': len(main_summary), 'vt_structure': len(vt_summary)},
        'weight_definition': 'W = solve(G, C); own_trait_weight is the common diagonal; other_trait_weight is each common off-diagonal.',
        'ratio_definition': 'other_trait_weight / own_trait_weight, computed for each replicate before summarizing.',
        'method': 'Original round-five compound-symmetric reconstruction from saved pooled covariance moments.',
        'parental_transmission_coefficients': False,
        'max_absolute_validation_errors': errors, 'minimum_G_eigenvalue': minimum_eigenvalue,
        'figure_quantity_checks': figure_checks,
        'covered_displays': ['Figure 4b-c', 'Extended Data Figure 4', 'Extended Data Figure 5', 'Supplementary Figure S17', 'Tables S7-S8'],
        'scope_limit': 'This package covers the decomposition campaigns only. It does not establish coverage of every VT example elsewhere in the manuscript or supplement.',
        'simulations_rerun': False,
    }
    (ROOT / 'provenance/apparent_weights_verification.json').write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
