#!/usr/bin/env Rscript
## plot_fig3_vdecomp_r5.R   (ROUND 5 — non-destructive copy of scripts/plot_fig3_vdecomp.R)
## Revised Figure 3 for the round-5 response: the middle decomposition tier is now the
## EXACT apparent (BLP) quantity (was predictive R²_g / r_cross r×); "Population h²"→"Direct h²".
## Landscape alternative: a compact column of schematics on the left,
## with panels b-d horizontally compressed on the right.
## Native 180 x 140 mm variant; typography is not scaled down with the page.
## Data/statistics are unchanged.
## Outputs: output/submission/.

library(ggplot2)
library(cowplot)
library(splines)
library(magick)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this script with Rscript.")
BASE_DIR <- normalizePath(file.path(dirname(sub("^--file=", "", script_arg)), ".."), mustWork = TRUE)
PROC_DIR <- file.path(BASE_DIR, "processed")
FIG_DIR  <- file.path(BASE_DIR, "output", "submission")
dir.create(FIG_DIR, showWarnings = FALSE, recursive = TRUE)

FIGURE_WIDTH_MM <- 180
FIGURE_HEIGHT_MM <- 140
PANEL_A_WIDTH_MM <- 64
COLUMN_GAP_MM <- 3
PLOTS_WIDTH_MM <- 113  # Native-size plots, with 6–7 pt labels retained.
# Keep b shorter than c/d in the same proportions as the revised portrait version.
PLOT_REL_HEIGHTS <- c(b = 35.72, c = 44.65, d = 47)

## ── Themes (unchanged) ──────────────────────────────────────────────────────
default_theme  <- theme_bw()      + theme(text = element_text(size = 14, family = "Helvetica"))
default_theme2 <- theme_minimal() + theme(text = element_text(size = 14, family = "Helvetica"))
PAL <- c("RM" = "#666666", "RM + VT" = "#CC79A7", "5xAM" = "#D55E00", "5xAM + VT" = "#0072B2")

## ── Load round-5 data ───────────────────────────────────────────────────────
h2_long <- read.csv(file.path(PROC_DIR, "fig3_vdecomp_r5_h2_long.csv"))
rg_long <- read.csv(file.path(PROC_DIR, "fig3_vdecomp_r5_rg_long.csv"))
fp_raw  <- read.csv(file.path(PROC_DIR, "fig3_vdecomp_r5_fp.csv"))

fig3_scens <- c("RM", "RM + VT", "5xAM", "5xAM + VT")

## NEW tier labels: Direct, Apparent, LDSC
h2_long$quantity <- factor(h2_long$quantity,
  levels = c("Direct h²", "Apparent h²", "LDSC h²"),
  labels = c("Direct~italic(h)^2", "Apparent~italic(h)^2", "LDSC~hat(italic(h))^2"))
rg_long$quantity <- factor(rg_long$quantity,
  levels = c("Direct r_g", "Apparent r_g", "LDSC r_g"),
  labels = c("Direct~italic(r)[g]", "Apparent~italic(r)[g]", "LDSC~hat(italic(r))['\U1D6FD']"))

## ── Panel a: schematic (serves as legend) ──────────────────────────────────
# Trim each model to its visible content and pack four models with 4 mm gaps.
# Use a common 69% scale of the original schematic to fit the 64 mm column.
schematic_scale <- 0.69
schematic_names <- c("rm", "rm_vt", "am", "am_vt")
schematic_render_width <- 1800
original_column_width_mm <- 86.4
schematic_images <- lapply(schematic_names, function(model) {
  image_trim(image_read_svg(file.path(BASE_DIR, "assets", "submission",
    paste0("fig3_schematic_", model, ".svg")), width = schematic_render_width))
})
schematic_layout <- data.frame(
  model = schematic_names, scale = schematic_scale,
  width_mm = vapply(schematic_images, function(img) image_info(img)$width,
                    numeric(1)) / schematic_render_width * original_column_width_mm * schematic_scale,
  height_mm = vapply(schematic_images, function(img) image_info(img)$height,
                     numeric(1)) / schematic_render_width * original_column_width_mm * schematic_scale
)
schematic_gap_mm <- 4
packed_height_mm <- sum(schematic_layout$height_mm) +
  schematic_gap_mm * (length(schematic_images) - 1)
stopifnot(packed_height_mm <= FIGURE_HEIGHT_MM,
          all(schematic_layout$width_mm < PANEL_A_WIDTH_MM))
top_mm <- (FIGURE_HEIGHT_MM - packed_height_mm) / 2
panel_a <- ggdraw()
for (i in seq_along(schematic_images)) {
  w <- schematic_layout$width_mm[i] / PANEL_A_WIDTH_MM
  h <- schematic_layout$height_mm[i] / FIGURE_HEIGHT_MM
  center_y <- 1 - (top_mm + schematic_layout$height_mm[i] / 2) / FIGURE_HEIGHT_MM
  panel_a <- panel_a + draw_image(schematic_images[[i]],
    x = (1 - w) / 2, y = center_y - h / 2, width = w, height = h)
  schematic_layout$center_x[i] <- 0.5
  schematic_layout$center_y[i] <- center_y
  top_mm <- top_mm + schematic_layout$height_mm[i] + schematic_gap_mm
}
write.csv(schematic_layout, file.path(FIG_DIR, "Fig_3_schematic_layout.csv"), row.names = FALSE)

## ── Panel b: h² decomposition ──────────────────────────────────────────────
h2_fig3 <- h2_long[h2_long$h2_param == 0.5 & h2_long$scenario %in% fig3_scens, ]
h2_fig3$scenario <- factor(h2_fig3$scenario, levels = fig3_scens)

plot_h2 <- ggplot(h2_fig3, aes(x = gen, y = h2, color = scenario, linetype = scenario)) +
  default_theme2 +
  geom_hline(yintercept = 0.5, color = "grey", lty = 1) +
  stat_summary(geom = "linerange", position = position_dodge(width = 0.3),
               fun.max = function(x) quantile(x, 0.9),
               fun.min = function(x) quantile(x, 0.1),
               fun     = function(x) quantile(x, 0.5)) +
  stat_summary(geom = "path", fun = median, linewidth = 1, position = position_dodge(width = 0.3)) +
  stat_summary(geom = "point", fun = median, size = 2, position = position_dodge(width = 0.3)) +
  facet_wrap(~ quantity, drop = TRUE, labeller = label_parsed) +
  scale_color_manual(values = PAL) +
  scale_linetype_manual(values = setNames(c(2:5), fig3_scens)) +
  ylab(NULL) + xlab("Generations of xAM")

## ── Panel c: rg decomposition ──────────────────────────────────────────────
rg_fig3 <- rg_long[rg_long$h2_param == 0.5 & rg_long$scenario %in% fig3_scens, ]
rg_fig3$scenario <- factor(rg_fig3$scenario, levels = fig3_scens)

plot_rg <- ggplot(rg_fig3, aes(x = gen, y = rg, color = scenario, linetype = scenario)) +
  default_theme2 +
  geom_hline(yintercept = 0, color = "grey", lty = 1) +
  stat_summary(geom = "linerange", position = position_dodge(width = 0.3),
               fun.max = function(x) quantile(x, 0.9),
               fun.min = function(x) quantile(x, 0.1),
               fun     = function(x) quantile(x, 0.5)) +
  stat_summary(geom = "path", fun = median, linewidth = 1, position = position_dodge(width = 0.3)) +
  stat_summary(geom = "point", fun = median, size = 2, position = position_dodge(width = 0.3)) +
  facet_wrap(~ quantity, drop = TRUE, labeller = label_parsed) +
  scale_color_manual(values = PAL) +
  scale_linetype_manual(values = setNames(c(2:5), fig3_scens)) +
  ylab(NULL) + xlab("Generations of xAM")

## ── Panel d: GWAS FP inflation (unchanged) ─────────────────────────────────
gwas_scens <- c("RM", "RM + VT", "5xAM", "5xAM + VT")
fp_pop <- fp_raw[fp_raw$GWAS == "Population" & fp_raw$scenario %in% gwas_scens, ]
fp_pop$scenario <- factor(fp_pop$scenario, levels = gwas_scens)
fp_pop$power_pct <- gsub("%", "", fp_pop$power)
fp_pop$power_label <- factor(paste0(fp_pop$power_pct, "*'%'~power~at~alpha==0.05"))

plot_fp <- ggplot(fp_pop, aes(gen, relative_T1R, color = scenario, lty = scenario, shape = scenario)) +
  default_theme +
  geom_hline(color = "grey", lty = 1, yintercept = 1) +
  stat_summary(geom = "point", position = position_dodge(width = 0.1), fun = median) +
  stat_summary(geom = "path", position = position_dodge(width = 0.1), fun = median, linewidth = 1) +
  facet_grid(~ power_label, labeller = label_parsed) +
  scale_color_manual(values = PAL[gwas_scens]) +
  scale_linetype_manual(values = setNames(c(2:5), gwas_scens)) +
  ylab(expression(over("Empirical Type-I Error Rate", "Theoretical Type-I Error Rate"))) +
  xlab("Generations of xAM") +
  theme(axis.title.x = element_blank()) +
  theme(legend.position = c(0.5, 0.9), legend.direction = "horizontal",
        legend.key.width = unit(1, "cm"))

## ── Landscape assembly ─────────────────────────────────────────────────────
publication_theme <- theme(
  text = element_text(family = "sans", size = 7),
  axis.text = element_text(size = 6, color = "#333333"),
  axis.title = element_text(size = 7),
  strip.text = element_text(size = 7),
  panel.grid.minor = element_blank(),
  panel.spacing.x = unit(1.5, "mm"),
  legend.position = "none",
  plot.margin = margin(5, 3, 2, 3, unit = "pt")
)
plot_h2 <- plot_h2 + publication_theme + theme(axis.title.x = element_blank())
plot_rg <- plot_rg + publication_theme + theme(axis.title.x = element_blank())
plot_fp <- plot_fp + publication_theme +
  theme(axis.title.x = element_text(size = 7), axis.title.y = element_text(size = 6),
        strip.background = element_rect(fill = "grey94", color = "grey60", linewidth = 0.25))
for (i in 1:3) {
  if (i == 1) p <- plot_h2 else if (i == 2) p <- plot_rg else p <- plot_fp
  p$layers[[1]]$aes_params$linewidth <- 0.25
  if (i < 3) {
    p$layers[[2]]$aes_params$linewidth <- 0.3
    p$layers[[3]]$aes_params$linewidth <- 0.5
    p$layers[[4]]$aes_params$size <- 1.2
  } else {
    p$layers[[2]]$aes_params$size <- 1.2
    p$layers[[3]]$aes_params$linewidth <- 0.5
  }
  if (i == 1) plot_h2 <- p else if (i == 2) plot_rg <- p else plot_fp <- p
}
plts <- align_plots(plot_h2, plot_rg, plot_fp, align = "v", axis = "lr")
right_column <- plot_grid(
  plts[[1]], plts[[2]], plts[[3]], ncol = 1, rel_heights = PLOT_REL_HEIGHTS,
  labels = c("b", "c", "d"), label_size = 7,
  label_fontfamily = "sans", label_x = 0, label_y = 1, hjust = 0, vjust = 1
)
fig3 <- plot_grid(
  panel_a, NULL, right_column,
  nrow = 1, rel_widths = c(PANEL_A_WIDTH_MM, COLUMN_GAP_MM, PLOTS_WIDTH_MM),
  labels = c("a", "", ""), label_size = 7,
  label_fontfamily = "sans", label_x = 0, label_y = 1, hjust = 0, vjust = 1
)

ggsave(file.path(FIG_DIR, "Fig_3.pdf"), fig3, width = FIGURE_WIDTH_MM, height = FIGURE_HEIGHT_MM, units = "mm", device = cairo_pdf)
ggsave(file.path(FIG_DIR, "Fig_3.png"), fig3, width = FIGURE_WIDTH_MM, height = FIGURE_HEIGHT_MM, units = "mm", dpi = 300, bg = "white")
cat("Saved Figure 3 submission-size PDF/PNG to", FIG_DIR, "\n")
cat("\n=== plot_fig3_vdecomp_r5.R complete ===\n")

saveRDS(list(a = panel_a, b = plot_h2, c = plot_rg, d = plot_fp),
        file.path(FIG_DIR, "Fig_3_panels.rds"))
write.csv(h2_fig3, file.path(FIG_DIR, "Fig_3_panel_b.csv"), row.names = FALSE)
write.csv(rg_fig3, file.path(FIG_DIR, "Fig_3_panel_c.csv"), row.names = FALSE)
write.csv(fp_pop, file.path(FIG_DIR, "Fig_3_panel_d.csv"), row.names = FALSE)
capture.output(sessionInfo(), file = file.path(FIG_DIR, "Fig_3_sessionInfo.txt"))
