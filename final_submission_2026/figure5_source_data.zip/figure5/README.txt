Scope: Figure 5, 200 replicates, generations 0–5. No simulations rerun.

Origin: simulation campaign edu_no_CD_LS.01; original parsed inputs are supplied in inputs/parsed/.

Recorded parameters: args_n=128000, args_m=2000, args_subsample=4000.

Plots: Figure 5b–d summaries contain medians used in the figure and means/SD/counts for transparency. Original analysis summary tables use means.

Weights: W=solve(G,C); rows index edu/height direct components, columns index edu/height/wealth phenotypes. Original covariance units.

Wealth: No independent direct genetic component exists for wealth. Both identified weights are provided; an own-weight ratio is undefined.

Projection: M=W.T@G@W; variance fraction=diag(M)/diag(Y); correlation from M. These are fitted direct-component projections, distinct from finite-sample HE estimates.

Figure 5b wealth line: The direct heritability of wealth (h2_true_wealth) is exactly zero. The original plotting code adds unseeded N(0,1e-6) display jitter; source data retain the model value of zero.

Figure 5c preprocessing: The original analysis replaces missing rg values with zero, values >5 with NA, then plots values <5. Both raw and processed values are retained.

Figure 5d preprocessing: The original analysis replaces missing values with zero, then plots values <5. Both raw and processed values are retained.

Undefined values: Blank numeric cells/NaN in CSV denote undefined or missing values, not zero.

Precision: CSV files preserve 17 significant digits; Excel retains approximately 15. See verification.json and original parsed files.
