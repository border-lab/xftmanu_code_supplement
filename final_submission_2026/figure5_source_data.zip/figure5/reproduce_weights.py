#!/usr/bin/env python3
"""Reproduce/check every Figure 5 weight and projected statistic from original CSVs.

Run with Python, numpy and pandas: python reproduce_weights.py
Reads files only. No simulations, random jitter, or external paths are used.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent

def main():
    originals=pd.concat([pd.read_csv(p) for p in sorted((ROOT/'inputs/parsed').glob('*_parsed.csv'))])
    weights=pd.read_csv(ROOT/'tables/fitted_weights.csv').set_index(['seed','gen','genetic_component','outcome'])
    projected=pd.read_csv(ROOT/'tables/projection_replicates.csv').set_index(['seed','gen','quantity','trait_1','trait_2'])
    genetic=['edu','height'];traits=genetic+['wealth'];errors=[]
    for r in originals.to_dict('records'):
        def cov(a,b):
            return r[f'cov_{a}_{b}'] if f'cov_{a}_{b}' in r else r[f'cov_{b}_{a}']
        gs=[g+'.addGen' for g in genetic];ys=[t+'.phenotype' for t in traits]
        G=np.array([[cov(a,b) for b in gs] for a in gs])
        C=np.array([[cov(a,b) for b in ys] for a in gs])
        Y=np.array([[cov(a,b) for b in ys] for a in ys])
        W=np.linalg.solve(G,C);M=W.T@G@W
        h2=M.diagonal()/Y.diagonal();rg=M/np.sqrt(np.outer(M.diagonal(),M.diagonal()))
        for i,g in enumerate(genetic):
            for j,t in enumerate(traits):errors.append(abs(W[i,j]-weights.loc[(r['seed'],r['gen'],g,t),'value']))
        for j,t in enumerate(traits):
            errors.append(abs(h2[j]-projected.loc[(r['seed'],r['gen'],'projected_variance_fraction',t,t),'value']))
            for k in range(j+1,3):errors.append(abs(rg[j,k]-projected.loc[(r['seed'],r['gen'],'projected_correlation',t,traits[k]),'value']))
    assert len(originals)==1200 and max(errors)<1e-12
    print(f'Verified {len(originals)} replicate-generation rows; maximum error {max(errors):.3g}.')

if __name__=='__main__':main()
